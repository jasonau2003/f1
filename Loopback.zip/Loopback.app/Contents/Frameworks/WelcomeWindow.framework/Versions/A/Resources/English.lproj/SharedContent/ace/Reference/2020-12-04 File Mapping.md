An (attempted) simple mapping of these files.

# Install, First Page

**Intel:** secure-install-intel.html

**Apple Silicon:** secure-install-mchip.html

**10.15 or lower, as well as ACE-previously-approved:** simple-install1.html

# Install, Second Page

**Intel:** secure-ACEapproval-intel.html

**Apple Silicon:** 
  - If System Extensions are not yet allowed: secure-systemextensionapproval-mchip.html
  - If System Extensions are already allowed: secure-ACEapproval-mchip.html


**10.15 or lower, as well as ACE-previously-approved [1]:** simple-install2.html


# Update

**Any platform, 10.16 or higher** secure-update-fromoldOS.html

**Any platform:** update1.html, update2.html

# Uninstall

**Any platform:** uninstall1.html, uninstall2.html

# Reinstall

**Any platform:** reinstall1.html, reinstall2.html


# Notes

[1] This is now possible to know, thanks to changes from Ed as of ~2020-12-04.
